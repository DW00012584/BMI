package p;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class BMI_h {

	public static void main(String[] args) throws IOException{

		try {
				System.out.println("身長と体重を入力して下さい");
				//標準入力を受け付けるためのBufferedReaderオブジェクト
				BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

				//標準入力された文字列をreadLine()メソッドで読み込み、String型変数strに代入
				String str1 = reader.readLine();
				String str2 = reader.readLine();

				//String型からdoble型に変換
				double h = Double.parseDouble(str1);
				double w = Double.parseDouble(str2);

				//cmをmに直す
				h *= 0.01;
				double bmi = w / (h * h);
				double tekisei = (h * h) * 22;
				double sa = w - tekisei;

				//小数点第2位で切り上げたBMIとif関数を使い日本肥満学会の判定基準を基にした肥満度、適正体重、体重と適正体重の差を出力する
				if(bmi < 18.5) {
					System.out.println("BMIは" + (Math.round( bmi*10.0 )/10.0) + "〔低体重(痩せ型)〕 \n 適正体重は" + ((Math.round(tekisei * 10.0)) /  10.0) + "です。"+ "差は" + ((Math.round(sa) * 10.0)) /  10.0);
					}else if(bmi < 25)  {
						System.out.println("BMIは" + ((Math.round( bmi*10.0 )/10.0) /  100) + "〔普通体重です〕 \n 適正体重は" + ((Math.round(tekisei * 10.0)) /  10.0) + "です."+ "差は" + ((Math.round(sa) * 10.0)) /  10.0);
					}else if(bmi < 30) {
						System.out.println("BMIは" + ((Math.round( bmi*10.0 )/10.0) /  100) + "で肥満(1度)です。\n 適正体重は" + ((Math.round(tekisei * 10.0)) /  10.0) + "です。" + "差は" + ((Math.round(sa) * 10.0)) /  10.0);
					}else if(bmi < 35) {
						System.out.println("BMIは" + (Math.round( bmi*10.0 )/10.0) + "で肥満(2度)です。\n 適正体重は" + ((Math.round(tekisei * 10.0)) /  10.0) + "です。" + "差は" + ((Math.round(sa) * 10.0)) /  10.0);
					}else if(bmi < 40) {
						System.out.println("BMIは" + (Math.round( bmi*10.0 )/10.0) + "で肥満(3度)です。 \n 適正体重は" + ((Math.round(tekisei * 10.0)) /  10.0) + "です。" + "差は" + ((Math.round(sa) * 10.0)) /  10.0);
					}else  if(bmi >= 40) {
						System.out.println("BMIは" + (Math.round( bmi*10.0 )/10.0) + "で肥満(4度)です。\n 適正体重は" + ((Math.round(tekisei * 10.0)) /  10.0) + "です。" + "差は" + ((Math.round(sa) * 10.0)) /  10.0);
					}
			} catch( Exception e ) {
	            System.out.println( "例外が発生しました: " + e );
	        }
		}

	}
